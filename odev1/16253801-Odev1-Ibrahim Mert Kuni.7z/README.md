install netbeans
cygwin
	install cypwin
	select these
		gcc-core
		gcc-g++
		gdb
		make
	to Enviroment Variables/Path... C:\cygwin64 
	
open netbeans
tools
plugins
setting
click portal
available plugins
check for newest
add c/c++ plugin

add project
project right click then properties
Run tab
Console Type
External Terminal